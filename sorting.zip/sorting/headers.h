#ifndef HEADER_H
#define HEADER_H

#include <bits/stdc++.h>
#include <iostream>
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <vector>

#endif